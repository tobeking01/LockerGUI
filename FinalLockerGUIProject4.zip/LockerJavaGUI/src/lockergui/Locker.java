/**
 * @author Tobechi Onwenu
 * Instructor: Bradford Armitage
 * Title: Locker GUI application (project step 4)
 * Description: An application that connects to the SQL database and 
 * allows the user to query based on the where clause typed in. 
 * 
 * Class details: Locker class connects to the SQL locker database (Not server based)
 */

package lockergui;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class Locker {

	// Protected connection variable
	protected Connection conn = null;

	public static Connection dbConnector() {
		try {
			// register MySQL thin driver with DriverManager service
			// It is optional for JDBC4.x version
			Class.forName("com.mysql.cj.jdbc.Driver");

			// variables
			final String url = "jdbc:mysql:///locker";
			final String user = "root";
			final String password = "JaYDeN01?";

			// establish the connection
			Connection conn = DriverManager.getConnection(url, user, password);

			// Connection message
			JOptionPane.showMessageDialog(null, "Connection Succesful");
			return conn;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
}
