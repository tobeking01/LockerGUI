/**
 * @author Tobechi Onwenu
 * Instructor: Bradford Armitage
 * Title: Locker GUI application (project step 4)
 * Description: An application that connects to the SQL database and 
 * allows the user to query based on the where clause typed in. 
 * 
 * Class details: Query class connects to the Locker class and utilizes the JTable to answer queries 
 */

package lockergui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

public class Query {

	// Private variables for query table
	private JFrame frame;
	private Connection connection = null;
	private JLabel EmpDeliveryLB;
	private JTable table;
	private JButton empDataButton;
	private JButton ClearButton;
	private JTextField EmpFirstnameField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Query window = new Query();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Query() {
		initialize();
		connection = Locker.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1034, 596);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		/**
		 * Employee title label
		 */
		EmpDeliveryLB = new JLabel("Employee Delivery Details");
		EmpDeliveryLB.setForeground(new Color(0, 0, 139));
		EmpDeliveryLB.setFont(new Font("Times New Roman", Font.BOLD, 18));
		EmpDeliveryLB.setBounds(547, 22, 262, 39);
		frame.getContentPane().add(EmpDeliveryLB);

		/**
		 * JScroolpane to slide table information
		 */
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(300, 74, 695, 361);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		/**
		 * Employee first name label
		 */
		JLabel EmpFirstnameLabel = new JLabel("Enter Emp Firstname below");
		EmpFirstnameLabel.setForeground(new Color(0, 0, 139));
		EmpFirstnameLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		EmpFirstnameLabel.setBounds(53, 119, 186, 29);
		frame.getContentPane().add(EmpFirstnameLabel);

		/**
		 * Load all Employee data variable and method
		 */
		empDataButton = new JButton("Load all Employee Data");
		empDataButton.setForeground(new Color(0, 0, 139));
		empDataButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		empDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					String query = "select * from employee";

					PreparedStatement pst = connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));

					pst.close();

				} catch (SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		empDataButton.setBounds(38, 412, 222, 23);
		frame.getContentPane().add(empDataButton);

		/**
		 * Clear button variable and method
		 */
		ClearButton = new JButton("Clear Table");
		ClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = new DefaultTableModel();
				table.setModel(model);
			}
		});
		ClearButton.setForeground(new Color(0, 0, 139));
		ClearButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		ClearButton.setBounds(70, 315, 141, 23);
		frame.getContentPane().add(ClearButton);

		/**
		 * Employee field variables
		 */
		EmpFirstnameField = new JTextField();
		EmpFirstnameField.setBounds(94, 159, 86, 20);
		frame.getContentPane().add(EmpFirstnameField);
		EmpFirstnameField.setColumns(10);

		/**
		 * Where clause query method and variable
		 */
		JButton QueryFirstNameButton = new JButton("Load Query Result");
		QueryFirstNameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "  SELECT \r\n" + "    CONCAT(employee.employeeFirstname,\r\n"
							+ "            ' ',\r\n" + "            employee.employeeLastname) AS EmployeeName,\r\n"
							+ "    department.departmentName,\r\n" + "    equipment.equipmentName,\r\n"
							+ "    request.requestQuantity,\r\n" + "    delivery.deliveryCompany,\r\n"
							+ "    delivery.deliveryStatus\r\n" + "FROM\r\n" + "    department\r\n" + "        JOIN\r\n"
							+ "    employee ON department.departmentid = employee.departmentid\r\n" + "        JOIN\r\n"
							+ "    request ON employee.employeeId = request.employeeId\r\n" + "        JOIN\r\n"
							+ "    equipment ON request.equipmentId = equipment.equipmentId\r\n" + "        JOIN\r\n"
							+ "    delivery ON request.requestid = delivery.requestid\r\n"
							+ "    where employee.employeeFirstname = ?";

					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, EmpFirstnameField.getText());
					ResultSet rs = pst.executeQuery();

					table.setModel(DbUtils.resultSetToTableModel(rs));

					pst.close();

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		QueryFirstNameButton.setForeground(new Color(0, 0, 139));
		QueryFirstNameButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		QueryFirstNameButton.setBounds(53, 208, 186, 23);
		frame.getContentPane().add(QueryFirstNameButton);
	}
}
